/* Profile covers 32, 33, 34. GameTime is the vanilla normalized day fraction. */
int ft_32_frame() {
    float t = mod(GameTime * 1200000.0, 710.0);
    t -= 40.0;
    if (t < 0.0) return 0;
    t -= 40.0;
    if (t < 0.0) return 1;
    t -= 50.0;
    if (t < 0.0) return 2;
    t -= 40.0;
    if (t < 0.0) return 3;
    t -= 40.0;
    if (t < 0.0) return 4;
    t -= 40.0;
    if (t < 0.0) return 5;
    t -= 40.0;
    if (t < 0.0) return 6;
    t -= 40.0;
    if (t < 0.0) return 7;
    t -= 50.0;
    if (t < 0.0) return 8;
    t -= 40.0;
    if (t < 0.0) return 9;
    t -= 40.0;
    if (t < 0.0) return 10;
    t -= 40.0;
    if (t < 0.0) return 11;
    t -= 40.0;
    if (t < 0.0) return 12;
    t -= 40.0;
    if (t < 0.0) return 13;
    t -= 50.0;
    if (t < 0.0) return 14;
    t -= 40.0;
    if (t < 0.0) return 15;
    return 16;
}

int ft_33_frame() {
    float t = mod(GameTime * 1200000.0, 4000.0);
    t -= 100.0;
    if (t < 0.0) return 0;
    t -= 100.0;
    if (t < 0.0) return 1;
    t -= 100.0;
    if (t < 0.0) return 2;
    t -= 100.0;
    if (t < 0.0) return 3;
    t -= 100.0;
    if (t < 0.0) return 4;
    t -= 100.0;
    if (t < 0.0) return 5;
    t -= 100.0;
    if (t < 0.0) return 6;
    t -= 100.0;
    if (t < 0.0) return 7;
    t -= 100.0;
    if (t < 0.0) return 8;
    t -= 100.0;
    if (t < 0.0) return 9;
    t -= 100.0;
    if (t < 0.0) return 10;
    t -= 100.0;
    if (t < 0.0) return 11;
    t -= 100.0;
    if (t < 0.0) return 12;
    t -= 100.0;
    if (t < 0.0) return 13;
    t -= 100.0;
    if (t < 0.0) return 14;
    t -= 100.0;
    if (t < 0.0) return 15;
    t -= 100.0;
    if (t < 0.0) return 16;
    t -= 100.0;
    if (t < 0.0) return 17;
    t -= 100.0;
    if (t < 0.0) return 18;
    t -= 100.0;
    if (t < 0.0) return 19;
    t -= 100.0;
    if (t < 0.0) return 20;
    t -= 100.0;
    if (t < 0.0) return 21;
    t -= 100.0;
    if (t < 0.0) return 22;
    t -= 100.0;
    if (t < 0.0) return 23;
    t -= 100.0;
    if (t < 0.0) return 24;
    t -= 100.0;
    if (t < 0.0) return 25;
    t -= 100.0;
    if (t < 0.0) return 26;
    t -= 100.0;
    if (t < 0.0) return 27;
    t -= 100.0;
    if (t < 0.0) return 28;
    t -= 100.0;
    if (t < 0.0) return 29;
    t -= 100.0;
    if (t < 0.0) return 30;
    t -= 100.0;
    if (t < 0.0) return 31;
    t -= 100.0;
    if (t < 0.0) return 32;
    t -= 100.0;
    if (t < 0.0) return 33;
    t -= 100.0;
    if (t < 0.0) return 34;
    t -= 100.0;
    if (t < 0.0) return 35;
    t -= 100.0;
    if (t < 0.0) return 36;
    t -= 100.0;
    if (t < 0.0) return 37;
    t -= 100.0;
    if (t < 0.0) return 38;
    return 39;
}

int ft_34_frame() {
    float t = mod(GameTime * 1200000.0, 700.0);
    t -= 100.0;
    if (t < 0.0) return 0;
    t -= 100.0;
    if (t < 0.0) return 1;
    t -= 100.0;
    if (t < 0.0) return 2;
    t -= 100.0;
    if (t < 0.0) return 3;
    t -= 100.0;
    if (t < 0.0) return 4;
    t -= 100.0;
    if (t < 0.0) return 5;
    return 6;
}

int ft_41_frame() {
    float t = mod(GameTime * 1200000.0, 2000.0);
    t -= 250.0;
    if (t < 0.0) return 0;
    t -= 250.0;
    if (t < 0.0) return 1;
    t -= 250.0;
    if (t < 0.0) return 2;
    t -= 250.0;
    if (t < 0.0) return 3;
    return 4;
}

vec4 ft_profile_process_color(vec4 inputColor, sampler2D glyphAtlas, vec2 glyphUv) {
    ivec3 rgb = ivec3(floor(inputColor.rgb * 255.0 + 0.5));
    bool frameColor = rgb.r == 254 && (
        (rgb.g == 166 && rgb.b >= 1 && rgb.b <= 17) ||
        (rgb.g == 167 && rgb.b >= 1 && rgb.b <= 40) ||
        (rgb.g == 168 && rgb.b >= 1 && rgb.b <= 7) ||
        (rgb.g == 169 && rgb.b >= 1 && rgb.b <= 5));
    if (!frameColor) return inputColor;

    // Only matching cover glyphs in minecraft:profile carry this invisible tag.
    // The atlas corner comes from UV, so shared-buffer baseVertex cannot alter it.
    ivec2 atlasSize = textureSize(glyphAtlas, 0);
    ivec2 pixel = clamp(ivec2(glyphUv * vec2(atlasSize)), ivec2(0), atlasSize - 1);
    // BitmapProvider uploads the full 256px cell, not its 176px ink width.
    // Keep tags inside the ink width to preserve the 177px text advance.
    // Map the right cell corners to the existing right-hand tags.
    if (all(equal(atlasSize, ivec2(256))) && pixel.x == 255 &&
        (pixel.y == 0 || pixel.y == 255)) pixel.x = 175;
    ivec4 tag = ivec4(floor(texelFetch(glyphAtlas, pixel, 0) * 255.0 + 0.5));
    if (!all(equal(tag, ivec4(37, rgb.g, rgb.b, 3)))) return inputColor;

    if (rgb.r == 254 && rgb.g == 166 && rgb.b >= 1 && rgb.b <= 17) {
        return vec4(1.0, 1.0, 1.0, ft_32_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 167 && rgb.b >= 1 && rgb.b <= 40) {
        return vec4(1.0, 1.0, 1.0, ft_33_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 168 && rgb.b >= 1 && rgb.b <= 7) {
        return vec4(1.0, 1.0, 1.0, ft_34_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 169 && rgb.b >= 1 && rgb.b <= 5) {
        return vec4(1.0, 1.0, 1.0, ft_41_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }
    return inputColor;
}
